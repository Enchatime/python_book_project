from setuptools import setup

setup(
    name='import_test',
    version='1.0',
    author='GMAN',
    py_modules=['import_test'],
)